# -*- coding: utf-8 -*-
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

st.title("📊 Data Analysis")

if "dataset" in st.session_state:
    df = st.session_state["dataset"]

    st.markdown("### Dataset Overview")
    st.dataframe(df.head())

    st.markdown("### Basic Statistics")
    st.write(df.describe())

    st.markdown("### Potability Distribution")
    fig, ax = plt.subplots()
    df["potability"].value_counts().plot(kind="bar", ax=ax)
    ax.set_xlabel("Potability")
    ax.set_ylabel("Count")
    st.pyplot(fig)

else:
    st.warning("⚠ Please upload a dataset from the Home page first.")
