import streamlit as st
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import LSTM, Dense, Dropout
import os

# -----------------------------
# Config
# -----------------------------
MODEL_PATH = "lstm_water_quality.keras"
scaler = MinMaxScaler()

# -----------------------------
# LSTM model builder
# -----------------------------
def build_model(input_shape, output_dim):
    model = Sequential()
    model.add(LSTM(128, return_sequences=True, input_shape=input_shape))
    model.add(Dropout(0.2))
    model.add(LSTM(64))
    model.add(Dense(output_dim))
    model.compile(optimizer="adam", loss="mse")
    return model

# -----------------------------
# Train or load model
# -----------------------------
def get_model(data, retrain=False):
    global scaler

    # Normalize
    data_scaled = scaler.fit_transform(data)

    X, y = [], []
    time_steps = 12  # 12 months history
    for i in range(time_steps, len(data_scaled)):
        X.append(data_scaled[i - time_steps:i])
        y.append(data_scaled[i])
    X, y = np.array(X), np.array(y)

    if retrain or not os.path.exists(MODEL_PATH):
        model = build_model((X.shape[1], X.shape[2]), y.shape[1])
        model.fit(X, y, epochs=5, batch_size=16, verbose=1)
        model.save(MODEL_PATH)
        return model
    else:
        return load_model(MODEL_PATH, compile=False)

# -----------------------------
# Forecast future values
# -----------------------------
def forecast_future(model, data, months=24):
    global scaler
    data_scaled = scaler.transform(data)

    last_seq = data_scaled[-12:]
    predictions = []

    for _ in range(months):
        pred = model.predict(last_seq[np.newaxis, :, :], verbose=0)
        predictions.append(pred[0])
        last_seq = np.vstack([last_seq[1:], pred])

    predictions = scaler.inverse_transform(predictions)
    return predictions

# -----------------------------
# Streamlit UI
# -----------------------------
st.title("💧 Water Quality Forecasting (LSTM)")

uploaded_file = st.file_uploader("📂 Upload your water quality CSV", type=["csv"])

if uploaded_file:
    df = pd.read_csv(uploaded_file, parse_dates=["date"])
    df = df.set_index("date")

    # ✅ Keep only numeric columns
    numeric_df = df.select_dtypes(include=[np.number])

    if numeric_df.empty:
        st.error("❌ No numeric columns found in dataset. Please upload water quality data with numeric values.")
    else:
        st.write("📊 Dataset Preview:")
        st.dataframe(df.head())

        # Retrain button
        if st.button("🔄 Retrain Model"):
            model = get_model(numeric_df.values, retrain=True)
            st.success("✅ Model retrained successfully!")
        else:
            model = get_model(numeric_df.values, retrain=False)
            st.info("ℹ️ Loaded existing model")

        # Forecast horizon
        months = st.slider("⏳ Forecast Months", 6, 60, 24)

        # Forecast
        forecast = forecast_future(model, numeric_df.values, months=months)

        forecast_df = pd.DataFrame(
            forecast,
            columns=numeric_df.columns,
            index=pd.date_range(df.index[-1] + pd.Timedelta(days=30),
                                periods=months, freq="M")
        )

        st.subheader("🔮 Forecasted Values")
        st.line_chart(forecast_df)
        st.dataframe(forecast_df)
