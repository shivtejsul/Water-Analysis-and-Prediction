# -*- coding: utf-8 -*-

import streamlit as st

st.title("💬 Feedback")

name = st.text_input("Your Name")
email = st.text_input("Your Email")
feedback = st.text_area("Your Feedback")

if st.button("Submit Feedback"):
    with open("feedback.txt", "a") as f:
        f.write(f"{name},{email},{feedback}\n")
    st.success("✅ Thank you for your feedback!")
