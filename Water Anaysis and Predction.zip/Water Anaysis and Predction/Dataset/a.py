import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Generate synthetic data
np.random.seed(42)
n_rows = 1000

locations = ["Vijayawada Barrage", "Srisailam Dam", "Nagarjuna Sagar Dam", 
             "Almatti Dam", "Sangli Monitoring Station", "Kurnool City", 
             "Karad Town", "Pulichintala Project", "Jurala Dam", "Mahagaon Village"]

data = {
    "Station-Location": np.random.choice(locations, n_rows),
    "Distance in Kms.": np.random.randint(0, 500, n_rows),
    "Dissolved Oxygen during 1986 (mg/l)": np.round(np.random.uniform(6.0, 7.5, n_rows), 1),
    "Biological Oxygen demand during 2011 (mg/l)": np.round(np.random.uniform(2.5, 4.0, n_rows), 1),
    "ph": np.round(np.random.uniform(6.5, 7.5, n_rows), 1),
    "hardness": np.random.randint(100, 150, n_rows),
    "solids": np.random.randint(350, 550, n_rows),
    "chloramines": np.round(np.random.uniform(1.5, 2.7, n_rows), 1),
    "sulfate": np.random.randint(90, 150, n_rows),
    "conductivity": np.random.randint(400, 550, n_rows),
    "organic_carbon": np.round(np.random.uniform(3.0, 4.7, n_rows), 1),
    "trihalomethanes": np.random.randint(35, 65, n_rows),
    "turbidity": np.round(np.random.uniform(1.5, 3.0, n_rows), 1),
    "potability": np.random.randint(0, 2, n_rows),
    "date": [datetime(1986, 1, 1) + timedelta(days=np.random.randint(0, 10000)) for _ in range(n_rows)]
}

df = pd.DataFrame(data)
df.to_csv("Krishna_River_Dataset.csv", index=False)
print("CSV file generated successfully!")